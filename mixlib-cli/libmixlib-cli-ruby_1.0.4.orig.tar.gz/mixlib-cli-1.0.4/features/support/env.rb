$LOAD_PATH.unshift(File.dirname(__FILE__) + '/../../lib')
require 'mixlib_cli'

require 'spec/expectations'

World do |world|
  
  world
end
