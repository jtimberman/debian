require 'systemu'


systemu 'date' do |cid|
  p cid
end
