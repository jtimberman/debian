Samples of how to use the ruby stomp client with stompserver
