<ul>
<% for item in list %>
  <li><%= item[:name]] %></li>
<% end %>
</ul>
