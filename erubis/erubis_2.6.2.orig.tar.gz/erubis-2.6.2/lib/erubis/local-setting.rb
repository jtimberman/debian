##
## $Rev: 77 $
## $Release: 2.6.2 $
## copyright(c) 2006-2008 kuwata-lab.com all rights reserved.
##

##
## you can add site-local settings here.
## this files is required by erubis.rb
##
