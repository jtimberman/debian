require File.dirname(__FILE__) + "/../../lib/ohai"

gem 'cucumber'
require 'cucumber'
gem 'rspec'
require 'spec'
