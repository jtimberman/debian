#$ psrinfo -v
#Status of virtual processor 0 as of: 01/11/2009 23:31:55
#  on-line since 05/29/2008 15:05:28.
#  The i386 processor operates at 2660 MHz,
#        and has an i387 compatible floating point processor.
#Status of virtual processor 1 as of: 01/11/2009 23:31:55
#  on-line since 05/29/2008 15:05:30.
#  The i386 processor operates at 2660 MHz,
#        and has an i387 compatible floating point processor.
#Status of virtual processor 2 as of: 01/11/2009 23:31:55
#  on-line since 05/29/2008 15:05:30.
#  The i386 processor operates at 2660 MHz,
#        and has an i387 compatible floating point processor.
#Status of virtual processor 3 as of: 01/11/2009 23:31:55
#  on-line since 05/29/2008 15:05:30.
#  The i386 processor operates at 2660 MHz,
#        and has an i387 compatible floating point processor.
#Status of virtual processor 4 as of: 01/11/2009 23:31:55
#  on-line since 05/29/2008 15:05:30.
#  The i386 processor operates at 2660 MHz,
#        and has an i387 compatible floating point processor.
#Status of virtual processor 5 as of: 01/11/2009 23:31:55
#  on-line since 05/29/2008 15:05:30.
#  The i386 processor operates at 2660 MHz,
#        and has an i387 compatible floating point processor.
#Status of virtual processor 6 as of: 01/11/2009 23:31:55
#  on-line since 05/29/2008 15:05:30.
#  The i386 processor operates at 2660 MHz,
#        and has an i387 compatible floating point processor.
#Status of virtual processor 7 as of: 01/11/2009 23:31:55
#  on-line since 05/29/2008 15:05:30.
#  The i386 processor operates at 2660 MHz,
#        and has an i387 compatible floating point processor.
