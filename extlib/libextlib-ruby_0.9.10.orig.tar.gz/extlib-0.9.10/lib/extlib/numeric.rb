class Numeric
  def try_dup
    self
  end
end
