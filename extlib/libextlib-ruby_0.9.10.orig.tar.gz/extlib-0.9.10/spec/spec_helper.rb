
$TESTING=true
require "rubygems"
require "spec"
require "yaml"

require File.join(File.dirname(__FILE__), '..', 'lib', 'extlib')
