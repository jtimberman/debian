Merb Flat
==============

An example of a small Merb application. Uses a single views directory and one
controller file.

Start with

  merb
  
