Autotest.add_discovery { "merb" }
Autotest.add_discovery { "rspec" }