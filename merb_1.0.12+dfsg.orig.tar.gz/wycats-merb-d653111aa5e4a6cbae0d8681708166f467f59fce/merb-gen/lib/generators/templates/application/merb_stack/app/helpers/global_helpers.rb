module Merb
  module GlobalHelpers
    # helpers defined here available to all views.  
  end
end
