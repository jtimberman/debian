require File.dirname(__FILE__) + '/spec_helper'

describe "<%= base_name %>" do
  it "should do nothing" do
    true.should == true
  end
end