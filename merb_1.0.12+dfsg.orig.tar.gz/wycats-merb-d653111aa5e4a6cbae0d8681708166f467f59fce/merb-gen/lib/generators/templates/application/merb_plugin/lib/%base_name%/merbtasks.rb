namespace :<%= symbol_name %> do
  desc "Do something for <%= base_name %>"
  task :default do
    puts "<%= base_name %> doesn't do anything"
  end
end