require File.join( File.dirname(__FILE__), <%= go_up(modules.size + 1) %>, "spec_helper" )

describe <%= class_name %> do

  it "should have specs"

end