<% with_modules(modules) do -%>
class <%= class_name %> < Application

  def index
    render
  end
  
end
<% end -%>
