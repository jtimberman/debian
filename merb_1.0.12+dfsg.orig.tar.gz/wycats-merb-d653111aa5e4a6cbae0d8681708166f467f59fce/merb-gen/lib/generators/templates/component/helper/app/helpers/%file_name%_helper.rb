module Merb
<% with_modules(modules, :indent => 1) do -%>
  module <%= class_name %>Helper

  end
<% end -%>
end # Merb