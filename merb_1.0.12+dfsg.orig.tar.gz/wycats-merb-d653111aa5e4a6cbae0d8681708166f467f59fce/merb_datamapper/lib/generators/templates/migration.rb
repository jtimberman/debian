migration <%= current_migration_nr %>, :<%= migration_name %>  do
  up do
  end

  down do
  end
end
