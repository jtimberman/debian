### AUTOMATICALLY GENERATED. DO NOT EDIT!
require 'merb-auth-core'
require 'merb-auth-more'
require 'merb-auth-slice-password'
