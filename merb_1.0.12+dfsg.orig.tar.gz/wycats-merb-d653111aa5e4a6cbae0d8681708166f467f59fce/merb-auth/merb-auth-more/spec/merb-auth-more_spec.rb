require File.dirname(__FILE__) + '/spec_helper'

describe "merb-auth-more" do
end