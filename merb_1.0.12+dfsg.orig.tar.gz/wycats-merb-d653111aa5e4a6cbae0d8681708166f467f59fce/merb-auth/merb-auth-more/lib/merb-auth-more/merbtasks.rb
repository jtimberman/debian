namespace :"merb-auth_more" do
  desc "Do something for merb-auth-more"
  task :default do
    puts "merb-auth-more doesn't do anything"
  end
end