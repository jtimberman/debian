namespace :"merb-auth_core" do
  # desc "Do something for merb-auth-core"
  # task :default do
  #   puts "merb-auth-core doesn't do anything"
  # end
end