class MerbAuthSlicePassword::Application < Merb::Controller
  
  controller_for_slice
  
end