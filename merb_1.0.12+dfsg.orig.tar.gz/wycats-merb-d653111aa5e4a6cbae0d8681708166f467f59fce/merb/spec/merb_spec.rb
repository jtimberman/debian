require File.dirname(__FILE__) + '/spec_helper'

describe "merb" do
  it "should do nothing" do
    true.should == true
  end
end