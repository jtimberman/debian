

module Merb

  module GlobalHelper
    # helpers defined here available to all views.  
  end
end