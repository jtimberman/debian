class HackerModel < FakeModel
  def foo
    '&"<>'
  end
end
