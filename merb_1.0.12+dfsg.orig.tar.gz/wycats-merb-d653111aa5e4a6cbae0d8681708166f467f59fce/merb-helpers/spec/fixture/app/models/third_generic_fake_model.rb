class FakeModel3
  attr_accessor :foo, :bar
end
