class CheckBoxSpecs < SpecController
end
