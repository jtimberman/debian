class BoundHiddenFieldSpecs < SpecController
end
