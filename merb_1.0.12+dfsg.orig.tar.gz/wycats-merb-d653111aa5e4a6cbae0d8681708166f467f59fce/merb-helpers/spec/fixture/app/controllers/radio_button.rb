class RadioButtonSpecs < SpecController
end
