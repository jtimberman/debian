class RelativeDateSpecs < SpecController
end