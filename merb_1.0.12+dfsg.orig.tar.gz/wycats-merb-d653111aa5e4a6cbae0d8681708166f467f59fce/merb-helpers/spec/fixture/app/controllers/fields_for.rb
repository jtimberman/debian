class FieldsForSpecs < SpecController

end
