class CustomBuilderSpecs < SpecController
end
