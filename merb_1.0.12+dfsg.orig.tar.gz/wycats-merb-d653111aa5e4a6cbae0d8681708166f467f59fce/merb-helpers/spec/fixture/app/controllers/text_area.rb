class TextAreaSpecs < SpecController
end
