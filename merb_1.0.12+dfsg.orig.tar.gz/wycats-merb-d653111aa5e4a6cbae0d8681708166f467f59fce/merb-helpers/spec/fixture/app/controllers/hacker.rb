class Hacker < Application
end