class BoundTextAreaSpecs < SpecController
end
