class BoundPasswordFieldSpecs < SpecController
end
