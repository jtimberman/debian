class FormForSpecs < SpecController
end
