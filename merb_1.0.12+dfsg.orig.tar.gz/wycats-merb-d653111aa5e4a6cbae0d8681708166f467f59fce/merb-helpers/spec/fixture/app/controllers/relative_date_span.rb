class RelativeDateSpanSpecs < SpecController
end