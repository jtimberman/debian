class LabelSpecs < SpecController

end
