class OptionTagSpecs < SpecController
end
