class SubmitSpecs < SpecController
end
