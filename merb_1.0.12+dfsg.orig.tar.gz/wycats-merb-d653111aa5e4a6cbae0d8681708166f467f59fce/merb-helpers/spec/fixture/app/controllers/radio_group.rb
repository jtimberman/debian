class RadioGroupSpecs < SpecController
end
