class ButtonSpecs < SpecController
end
