class FieldsetSpecs < SpecController
end
