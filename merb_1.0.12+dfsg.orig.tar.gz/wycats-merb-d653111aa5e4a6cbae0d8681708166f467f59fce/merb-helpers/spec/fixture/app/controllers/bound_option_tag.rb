class BoundOptionTagSpecs < SpecController
end
