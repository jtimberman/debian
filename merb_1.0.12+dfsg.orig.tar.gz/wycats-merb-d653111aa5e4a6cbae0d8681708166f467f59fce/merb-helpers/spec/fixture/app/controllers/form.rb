class FormSpecs < SpecController
end
