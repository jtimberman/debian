class BoundSelectSpecs < SpecController
end
