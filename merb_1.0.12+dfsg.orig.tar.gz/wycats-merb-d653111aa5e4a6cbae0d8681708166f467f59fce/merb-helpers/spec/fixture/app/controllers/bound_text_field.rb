class BoundTextFieldSpecs < SpecController
end
