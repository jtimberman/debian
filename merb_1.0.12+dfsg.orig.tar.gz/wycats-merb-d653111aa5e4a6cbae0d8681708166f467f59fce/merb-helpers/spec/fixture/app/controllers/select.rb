class SelectSpecs < SpecController
end
