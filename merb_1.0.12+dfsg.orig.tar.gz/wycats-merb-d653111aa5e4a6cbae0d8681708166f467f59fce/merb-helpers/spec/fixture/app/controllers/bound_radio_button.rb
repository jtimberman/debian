class BoundRadioButtonSpecs < SpecController
end
