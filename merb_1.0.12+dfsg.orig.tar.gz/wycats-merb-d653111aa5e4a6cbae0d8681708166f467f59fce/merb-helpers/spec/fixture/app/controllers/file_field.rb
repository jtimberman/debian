class FileFieldSpecs < SpecController
end
