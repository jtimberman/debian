class BoundCheckBoxSpecs < SpecController
end
