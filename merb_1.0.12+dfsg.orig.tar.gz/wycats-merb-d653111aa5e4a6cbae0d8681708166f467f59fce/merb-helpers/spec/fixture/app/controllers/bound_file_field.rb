class BoundFileFieldSpecs < SpecController
end
