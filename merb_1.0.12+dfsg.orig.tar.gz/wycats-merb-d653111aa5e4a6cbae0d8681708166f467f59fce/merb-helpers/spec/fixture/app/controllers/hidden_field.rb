class HiddenFieldSpecs < SpecController
end
