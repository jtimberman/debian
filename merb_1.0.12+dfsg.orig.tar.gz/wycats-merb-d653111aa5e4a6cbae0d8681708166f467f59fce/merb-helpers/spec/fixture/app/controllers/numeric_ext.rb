class NumericExtSpecs < SpecController
  
end