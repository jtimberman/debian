class BoundRadioGroupSpecs < SpecController
end
