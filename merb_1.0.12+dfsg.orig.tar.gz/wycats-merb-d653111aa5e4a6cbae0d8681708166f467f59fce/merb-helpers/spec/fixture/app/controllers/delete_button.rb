class DeleteButtonSpecs < SpecController
end
