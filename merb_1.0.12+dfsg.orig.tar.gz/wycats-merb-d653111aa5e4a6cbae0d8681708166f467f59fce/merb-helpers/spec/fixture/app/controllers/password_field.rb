class PasswordFieldSpecs < SpecController
end
