module <%= module_name %>
  
  class Application < Merb::Controller    
  end
  
  class Main < Application
  end
  
end