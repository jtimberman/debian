class <%= module_name %>::Main < <%= module_name %>::Application
  
  def index
    render
  end
  
end