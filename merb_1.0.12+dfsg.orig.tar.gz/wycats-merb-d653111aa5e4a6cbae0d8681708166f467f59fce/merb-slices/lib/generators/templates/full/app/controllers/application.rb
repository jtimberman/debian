class <%= module_name %>::Application < Merb::Controller
  
  controller_for_slice
  
end