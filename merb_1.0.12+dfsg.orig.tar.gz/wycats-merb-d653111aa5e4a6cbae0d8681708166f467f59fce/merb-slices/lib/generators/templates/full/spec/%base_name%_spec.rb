require File.dirname(__FILE__) + '/spec_helper'

describe "<%= module_name %> (module)" do
  
  # Implement your <%= module_name %> specs here
  
  # To spec <%= module_name %> you need to hook it up to the router like this:
  
  # before :all do
  #   Merb::Router.prepare { add_slice(:<%= module_name %>) } if standalone?
  # end
  # 
  # after :all do
  #   Merb::Router.reset! if standalone?
  # end
  #
  #
  # it "should have proper specs"
  
end