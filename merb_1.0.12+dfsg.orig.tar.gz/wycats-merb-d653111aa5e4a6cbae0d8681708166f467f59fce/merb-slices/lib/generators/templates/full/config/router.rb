# This file is here so slice can be testing as a stand alone application.

#Merb::Router.prepare do
#  ... 
#end