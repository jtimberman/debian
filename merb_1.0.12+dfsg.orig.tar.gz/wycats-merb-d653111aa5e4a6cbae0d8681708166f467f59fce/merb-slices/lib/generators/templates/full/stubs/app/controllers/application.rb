class <%= module_name %>::Application < Merb::Controller
end