class <%= module_name %>::Main < <%= module_name %>::Application
end