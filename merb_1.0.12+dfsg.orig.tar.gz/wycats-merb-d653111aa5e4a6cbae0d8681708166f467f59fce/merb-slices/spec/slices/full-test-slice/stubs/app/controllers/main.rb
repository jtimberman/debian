class FullTestSlice::Main < FullTestSlice::Application
end