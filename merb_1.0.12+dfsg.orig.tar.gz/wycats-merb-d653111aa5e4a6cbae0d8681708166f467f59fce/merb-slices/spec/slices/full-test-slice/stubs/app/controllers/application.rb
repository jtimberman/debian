class FullTestSlice::Application < Merb::Controller
end