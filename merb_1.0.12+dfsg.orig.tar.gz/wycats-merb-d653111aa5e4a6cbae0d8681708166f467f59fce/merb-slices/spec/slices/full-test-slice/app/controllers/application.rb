class FullTestSlice::Application < Merb::Controller
  
  controller_for_slice
  
end