class FullTestSlice::Main < FullTestSlice::Application
  
  def index
    render
  end
  
end