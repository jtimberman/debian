require 'merb-gen'
require 'generators/mailer_generator'