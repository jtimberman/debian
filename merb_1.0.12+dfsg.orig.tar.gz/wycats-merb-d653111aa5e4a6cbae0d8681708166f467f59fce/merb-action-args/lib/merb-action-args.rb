require "merb-action-args/get_args"
require "merb-action-args/abstract_controller"
