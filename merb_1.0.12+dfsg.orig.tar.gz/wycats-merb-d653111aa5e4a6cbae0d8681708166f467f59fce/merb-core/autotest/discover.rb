Autotest.add_discovery do
  "merbsource"
end