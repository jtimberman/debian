

class Base < Application

  def string
    "String"
  end

  def template
    render
  end
  
end