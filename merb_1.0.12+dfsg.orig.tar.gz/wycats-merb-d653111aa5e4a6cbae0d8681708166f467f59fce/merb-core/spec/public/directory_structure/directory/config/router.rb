Merb::Router.prepare do |r|
  r.default_routes
end