class Merb::Test::ControllerAssertionMock
  
  def self.called(action)
    return action
  end
  
end