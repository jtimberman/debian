# namespace :merb_param_protection do
#   desc "Do something for merb_param_protection"
#   task :default do
#     puts "merb_param_protection doesn't do anything"
#   end
# end